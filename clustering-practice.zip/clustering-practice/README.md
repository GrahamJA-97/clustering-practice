# clustering-practice
A project to practice clustering in ML
